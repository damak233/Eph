import React from 'react'
export default function Home() {
  return (
    <main className="min-h-screen grid place-items-center" style={{background:'#000', color:'#fff'}}>
      <div style={{maxWidth:720,padding:24,textAlign:'center'}}>
        <h1 style={{fontSize:44,fontWeight:700,marginBottom:8}}>Ephemeral Moments</h1>
        <p style={{opacity:.8}}>Preview site is connected. Artwork & full content will be added next.</p>
        <p style={{marginTop:16,opacity:.7}}>Contact: ephemeralartco@gmail.com</p>
      </div>
    </main>
  )
}
